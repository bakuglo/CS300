//============================================================================
// Name        : FinalProject.cpp
// Author      : Dylan Bishop
// Version     :
// Copyright   : Your copyright notice
// Description : Final Project
//============================================================================

#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
using namespace std;

// Define a Course struct to store all course information
struct Course {
    string courseID;
    string courseName;
    string preReq1;
    string preReq2;
    Course* left;
    Course* right;
};

// Define a Binary Search Tree class to store the Course objects
class BinarySearchTree {
public:
    BinarySearchTree() {
        root = nullptr;
    }
    void insert(Course* course) {
        root = insertHelper(root, course);
    }
    void inorderTraversal() {
        inorderTraversalHelper(root);
    }
    Course* search(string courseID) {
        return searchHelper(root, courseID);
    }
private:
    Course* root;
    Course* insertHelper(Course* node, Course* course) {
        if (node == nullptr) {
            node = course;
        }
        else if (node->courseID > course->courseID) {
            node->left = insertHelper(node->left, course);
        }
        else {
            node->right = insertHelper(node->right, course);
        }
        return node;
    }
    void inorderTraversalHelper(Course* node) {
        if (node != nullptr) {
            inorderTraversalHelper(node->left);
            cout << node->courseID << ", " << node->courseName << endl;
            inorderTraversalHelper(node->right);
        }
    }
    Course* searchHelper(Course* node, string courseID) {
        if (node == nullptr || node->courseNumber == courseID) {
            return node;
        }
        else if (node->courseNumber > courseID) {
            return searchHelper(node->left, courseID);
        }
        else {
            return searchHelper(node->right, courseID);
        }
    }
};

// Define a CourseArray class to store the Course objects
class CourseArray {
public:
    CourseArray(int size) {
        capacity = size;
        courses = new Course * [capacity];
        numCourses = 0;
    }
    void add(Course* course) {
        courses[numCourses++] = course;
    }
    void sort() {
        std::sort(courses, courses + numCourses, [](const Course* a, const Course* b) {
            return a->courseID < b->courseID;
            });
    }
    void print() {
        for (int i = 0; i < numCourses; i++) {
            cout << courses[i]->courseID << ", " << courses[i]->courseName << endl;
        }
    }
    Course* search(string courseID) {
        for (int i = 0; i < numCourses; i++) {
            if (courses[i]->courseID == courseID) {
                return courses[i];
            }
        }
        return nullptr;
    }
private:
    Course** courses;
    int capacity;
    int numCourses;
};

// Define a function to parse a line of input and create a Course object
Course* parseCourse(string line) {
    Course* course = new Course;
    size_t commaPos1 = line.find(",");
    size_t commaPos2 = line.find(",", commaPos1 + 1);
    size_t commaPos3 = line.find(",", commaPos2 + 1);
    course->courseID = line.substr(0, commaPos1);
    course->courseName = line.substr(commaPos1 + 1, commaPos2 - commaPos1 - 1);
    course->preReq1 = preReq1;
    course->preReq2 = preReq2;
    course->preReq3 = preReq3;
    courseBST.insert(course);
}
inputFile.close();
cout << "Data loaded successfully." << endl;
}

// Function to print the course list in alphanumeric order
void printCourseList(BST<Course>& courseBST)
{
    // Create a vector to store all courses
    vector<Course> courses;

    // Traverse the Binary Search Tree and insert each course into the vector
    courseBST.inOrderTraversal([&](Course* course) {
        courses.push_back(*course);
        });

    // Sort the vector in alphanumeric order
    sort(courses.begin(), courses.end(), [](const Course& a, const Course& b) {
        return a.courseID < b.courseID;
        });

    // Print the sorted list of all of the courses
    cout << "List of all courses in the Computer Science department:" << endl;
    for (const Course& course : courses) {
        cout << course.courseID << ", " << course.courseName << endl;
    }
}

// Function to print course info
void printCourseInfo(BST<Course>& courseBST)
{
    string courseID;
    cout << "What course would you like to know about? ";
    cin >> courseID;

    // Search for course in the Binary Search Tree
    Course* course = courseBST.search(Course(courseID, ""));

    if (course != nullptr) {
        cout << course->courseID << ", " << course->courseName << endl;
        cout << "Prerequisites: ";
        if (!course->preReq1.empty()) {
            cout << course->preReq1;
            if (!course->preReq2.empty() || !course->preReq3.empty()) {
                cout << ", ";
            }
        }
        if (!course->preReq2.empty()) {
            cout << course->preReq2;
            if (!course->preReq3.empty()) {
                cout << ", ";
            }
        }
        if (!course->preReq3.empty()) {
            cout << course->preReq3;
        }
        cout << endl;
    }
    else {
        cout << "Course was not found." << endl;
    }
}

// Function to display the menu, handle user input
void displayMenu(BST<Course>& courseBST)
{
    int choice = 0;
    while (choice != 9) {
        cout << endl;
        cout << "1. Load Data Structure." << endl;
        cout << "2. Print Course List." << endl;
        cout << "3. Print Course." << endl;
        cout << "9. Exit" << endl;
        cout << endl;
        cout << "What would you like to do? ";
        cin >> choice;

        switch (choice) {
        case 1:
            loadDataStructure(courseBST);
            break;
        case 2:
            printCourseList(courseBST);
            break;
        case 3:
            printCourseInfo(courseBST);
            break;
        case 9:
            cout << "Thank you! Goodbye." << endl;
            break;
        default:
            cout << choice << " is not an option." << endl;
            break;
        }
    }
}
} // namespace abcucourseplanner

int main()
{
    // Create a Binary Search Tree to store courses
    BSTabcucourseplanner::Course courseBST;
    // Display the menu, handle user input
    abcucourseplanner::displayMenu(courseBST);

    return 0;

}